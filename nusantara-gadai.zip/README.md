
# Nusantara Gadai

Aplikasi penaksir nilai gadai barang elektronik berbasis web menggunakan React dan Vite.

## Fitur
- Input jenis, merek, model, tahun, kondisi, kelengkapan barang
- Hitung estimasi nilai gadai berdasarkan harga pasar (60%)
- Cepat dan ringan, siap untuk deployment ke Vercel

## Cara Menjalankan
```bash
npm install
npm run dev
```

## Deployment
Siap dideploy ke [Vercel](https://vercel.com)
