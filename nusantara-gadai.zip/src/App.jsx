
import { useState } from 'react';

function App() {
  const [formData, setFormData] = useState({
    jenis: '',
    merek: '',
    model: '',
    tahun: '',
    kondisi: '',
    kelengkapan: '',
    hargaPasar: ''
  });
  const [hasil, setHasil] = useState(null);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const hitungGadai = () => {
    const harga = parseFloat(formData.hargaPasar);
    if (!isNaN(harga)) {
      const nilaiGadai = Math.round(harga * 0.6);
      setHasil(nilaiGadai);
    }
  };

  return (
    <div style={{ maxWidth: '600px', margin: '0 auto', padding: '20px' }}>
      <h1>Penaksir Gadai Elektronik</h1>
      <div><label>Jenis Barang</label><input name="jenis" value={formData.jenis} onChange={handleChange} /></div>
      <div><label>Merek</label><input name="merek" value={formData.merek} onChange={handleChange} /></div>
      <div><label>Model</label><input name="model" value={formData.model} onChange={handleChange} /></div>
      <div><label>Tahun Pembelian</label><input name="tahun" value={formData.tahun} onChange={handleChange} /></div>
      <div><label>Kondisi</label><input name="kondisi" value={formData.kondisi} onChange={handleChange} /></div>
      <div><label>Kelengkapan</label><input name="kelengkapan" value={formData.kelengkapan} onChange={handleChange} /></div>
      <div><label>Harga Pasar (Rp)</label><input type="number" name="hargaPasar" value={formData.hargaPasar} onChange={handleChange} /></div>
      <button onClick={hitungGadai}>Hitung Nilai Gadai</button>
      {hasil !== null && <p>Estimasi nilai gadai: <strong>Rp {hasil.toLocaleString()}</strong></p>}
    </div>
  );
}

export default App;
